package com.spacemod;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;

/** Прогресс игрока (очки исследований, посещённые миры, наблюдения, кампания, колония). */
public final class SpaceData {
    private static final String PERSISTED = "PlayerPersisted";
    public static final int[] TECH_AT = {20, 45, 72, 100};
    public static final String[] TECH_NAMES = {"Усиленный сканер", "Ионный двигатель", "Анализатор экзоматерии", "Квантовая связь"};

    private SpaceData() {}

    public static CompoundTag root(Player p) {
        CompoundTag forge = p.getPersistentData();
        CompoundTag persisted = forge.getCompound(PERSISTED);
        forge.put(PERSISTED, persisted);
        CompoundTag mod = persisted.getCompound("spacemod");
        persisted.put("spacemod", mod);
        return mod;
    }

    public static void copy(Player from, Player to) {
        CompoundTag copy = root(from).copy();
        CompoundTag forge = to.getPersistentData();
        CompoundTag persisted = forge.getCompound(PERSISTED);
        forge.put(PERSISTED, persisted);
        persisted.put("spacemod", copy);
    }

    public static int research(Player p) {
        return root(p).getInt("research");
    }

    public static void addResearch(Player p, int amount) {
        CompoundTag r = root(p);
        int before = r.getInt("research");
        int after = before + amount;
        r.putInt("research", after);
        for (int i = 0; i < TECH_AT.length; i++) {
            if (before < TECH_AT[i] && after >= TECH_AT[i]) {
                p.displayClientMessage(Component.literal("Открыта технология: " + TECH_NAMES[i] + "!"), false);
            }
        }
    }

    public static int shipLevel(Player p) {
        return Math.min(5, 1 + research(p) / 30);
    }

    public static int techCount(Player p) {
        int n = 0;
        int research = research(p);
        for (int at : TECH_AT) {
            if (research >= at) n++;
        }
        return n;
    }

    /** index: 0 сканер, 1 ионный двигатель, 2 анализатор, 3 квантовая связь */
    public static boolean hasTech(Player p, int index) {
        return research(p) >= TECH_AT[index];
    }

    public static boolean has(CompoundTag root, String list, String value) {
        ListTag l = root.getList(list, Tag.TAG_STRING);
        for (int i = 0; i < l.size(); i++) {
            if (l.getString(i).equals(value)) return true;
        }
        return false;
    }

    /** @return true если значение добавлено впервые */
    public static boolean add(CompoundTag root, String list, String value) {
        if (has(root, list, value)) return false;
        ListTag l = root.getList(list, Tag.TAG_STRING);
        l.add(StringTag.valueOf(value));
        root.put(list, l);
        return true;
    }

    public static void say(Player p, String text) {
        p.displayClientMessage(Component.literal(text), false);
    }
}
