package com.spacemod;

import java.util.List;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;

/** Симуляция марсианской колонии «Заря» (порт из консольной версии), состояние хранится в NBT игрока. */
public final class ColonySim {
    private static final String[] CREW_NAMES = {"Анна Волкова", "Марк Орлов", "Лина Соколова", "Давид Ким"};
    private static final String[] CREW_ROLES = {"командир", "инженер", "биолог", "геолог"};
    private static final String[] ROVERS = {"«Следопыт»", "«Горизонт»", "«Фобос»", "«Персеверанс-2»"};
    public static final int SOLS = 12;
    private static final int CREW = 4;

    private ColonySim() {}

    public static CompoundTag fresh() {
        CompoundTag s = new CompoundTag();
        s.putInt("sol", 0);
        s.putInt("oxygen", 90);
        s.putInt("water", 48);
        s.putInt("food", 52);
        s.putInt("energy", 40);
        s.putInt("iron", 55);
        s.putInt("titanium", 20);
        s.putInt("habitat", 1);
        s.putInt("solar", 1);
        s.putInt("greenhouse", 0);
        s.putInt("pump", 0);
        s.putInt("lab", 0);
        s.putIntArray("health", new int[]{100, 100, 100, 100});
        s.putInt("research", 0);
        s.putInt("rover", 0);
        s.putInt("shortages", 0);
        s.putBoolean("finished", false);
        s.putBoolean("rewarded", false);
        s.put("tech", new ListTag());
        return s;
    }

    private static void ch(CompoundTag s, String key, int d) {
        s.putInt(key, s.getInt(key) + d);
    }

    public static boolean crewAlive(CompoundTag s) {
        for (int h : s.getIntArray("health")) {
            if (h == 0) return false;
        }
        return true;
    }

    /** Проводит один сол. @return true, если колония завершила работу. */
    public static boolean advance(CompoundTag s, List<String> out) {
        int sol = s.getInt("sol") + 1;
        s.putInt("sol", sol);
        out.add("--- Сол " + sol + " ---");
        event(s, sol, out);
        rover(s, sol, out);
        construct(s, sol, out);
        produce(s, out);
        research(s, out);
        health(s, sol, out);
        report(s, out);
        boolean danger = !crewAlive(s);
        if (danger) {
            out.add("Колония объявляет аварийный режим и прекращает плановые работы.");
        }
        if (danger || sol >= SOLS) {
            s.putBoolean("finished", true);
            finalReport(s, out);
            return true;
        }
        return false;
    }

    private static void event(CompoundTag s, int sol, List<String> out) {
        switch (sol) {
            case 2:
                ch(s, "energy", -10);
                out.add("Событие: пылевая буря закрыла солнечные панели; запас энергии уменьшился.");
                break;
            case 4:
                ch(s, "water", 12);
                out.add("Событие: георадар обнаружил залежь подповерхностного льда (+12 воды).");
                break;
            case 5:
                ch(s, "iron", -3);
                out.add("Событие: при ремонте шлюза использованы запчасти из запаса железа.");
                break;
            case 7: {
                ch(s, "energy", -8);
                int[] h = s.getIntArray("health");
                h[0] = Math.max(0, h[0] - 4);
                s.putIntArray("health", h);
                out.add("Событие: вспышка на Солнце повредила оборудование; экипаж укрылся в модуле.");
                break;
            }
            case 9:
                ch(s, "iron", 8);
                ch(s, "titanium", 2);
                out.add("Событие: найден метеорит с железом и титаном (+8 железа, +2 титана).");
                break;
            case 11:
                ch(s, "food", 6);
                out.add("Событие: экспериментальная культура дала дополнительный урожай (+6 еды).");
                break;
            default:
                out.add("Событие: штатный день, критических происшествий нет.");
        }
    }

    private static void rover(CompoundTag s, int sol, List<String> out) {
        if (sol % 3 == 0) {
            s.putInt("rover", s.getInt("rover") + 1);
            ch(s, "iron", 6);
            ch(s, "titanium", 2);
            out.add("Марсоход " + ROVERS[(s.getInt("rover") - 1) % ROVERS.length] + " вернулся: добыто 6 железа и 2 титана.");
        }
    }

    private static void construct(CompoundTag s, int sol, List<String> out) {
        switch (sol) {
            case 2: build(s, "greenhouse", "теплица", 12, 4, out); break;
            case 4: build(s, "pump", "ледяной бур", 10, 5, out); break;
            case 6: build(s, "lab", "лаборатория", 15, 4, out); break;
            case 8: build(s, "solar", "солнечная ферма", 8, 2, out); break;
            default: out.add("Строительство: техническое обслуживание имеющихся модулей.");
        }
    }

    private static void build(CompoundTag s, String key, String label, int iron, int titanium, List<String> out) {
        if (s.getInt("iron") < iron || s.getInt("titanium") < titanium) {
            out.add("Не удалось построить объект «" + label + "»: не хватает строительных материалов.");
            return;
        }
        ch(s, "iron", -iron);
        ch(s, "titanium", -titanium);
        ch(s, key, 1);
        out.add("Построен объект: " + label + " (" + iron + " железа, " + titanium + " титана).");
    }

    private static void produce(CompoundTag s, List<String> out) {
        int solar = s.getInt("solar");
        int gh = s.getInt("greenhouse");
        int pump = s.getInt("pump");
        int energyUse = 4 + gh * 2 + pump * 2 + s.getInt("lab") * 3;
        int energyGain = solar * 12;
        ch(s, "energy", energyGain - energyUse);
        int foodProduced = gh * CREW * 5;
        int oxygenProduced = gh * CREW * 4;
        ch(s, "water", pump * CREW * 4 - gh * 2 - CREW * 3);
        ch(s, "food", foodProduced - CREW * 4);
        ch(s, "oxygen", oxygenProduced - CREW * 4);
        out.add("Баланс за сол: энергия +" + energyGain + "/-" + energyUse + ", теплицы произвели "
                + foodProduced + " еды и " + oxygenProduced + " кислорода.");
    }

    private static void research(CompoundTag s, List<String> out) {
        int labs = s.getInt("lab");
        if (labs == 0) {
            out.add("Исследования: лаборатория ещё не построена.");
            return;
        }
        int points = labs * 5;
        s.putInt("research", s.getInt("research") + points);
        out.add("Лаборатория получила " + points + " очков исследований.");
        unlock(s, 10, "Закрытый цикл очистки воды", out);
        unlock(s, 20, "Улучшенные фотобиореакторы", out);
        unlock(s, 35, "Защита от радиации", out);
        unlock(s, 50, "Автономный геологический дрон", out);
    }

    private static void unlock(CompoundTag s, int threshold, String tech, List<String> out) {
        if (s.getInt("research") < threshold) return;
        ListTag list = s.getList("tech", Tag.TAG_STRING);
        for (int i = 0; i < list.size(); i++) {
            if (list.getString(i).equals(tech)) return;
        }
        list.add(StringTag.valueOf(tech));
        s.put("tech", list);
        out.add("Открыта технология: " + tech + "!");
    }

    private static void health(CompoundTag s, int sol, List<String> out) {
        int[] h = s.getIntArray("health");
        String[] keys = {"oxygen", "water", "food", "energy"};
        String[] labels = {"кислород", "вода", "еда", "энергия"};
        for (int i = 0; i < keys.length; i++) {
            if (s.getInt(keys[i]) < 0) {
                s.putInt("shortages", s.getInt("shortages") + 1);
                s.putInt(keys[i], 0);
                int idx = (sol + s.getInt("shortages")) % CREW;
                h[idx] = Math.max(0, h[idx] - 12);
                out.add("Дефицит ресурса «" + labels[i] + "»! Здоровье " + CREW_NAMES[idx] + " снизилось до " + h[idx] + "%.");
            }
        }
        for (int i = 0; i < CREW; i++) {
            if (h[i] < 100 && s.getInt("food") >= 4 && s.getInt("water") >= 3) {
                h[i] = Math.min(100, h[i] + 2);
            }
        }
        s.putIntArray("health", h);
    }

    private static void report(CompoundTag s, List<String> out) {
        out.add("Запасы: O₂ " + s.getInt("oxygen") + ", вода " + s.getInt("water") + ", еда " + s.getInt("food")
                + ", энергия " + s.getInt("energy") + ", железо " + s.getInt("iron") + ", титан " + s.getInt("titanium") + ".");
        out.add("Инфраструктура: жилые модули " + s.getInt("habitat") + ", теплицы " + s.getInt("greenhouse")
                + ", ледяные буры " + s.getInt("pump") + ", солнечные фермы " + s.getInt("solar")
                + ", лаборатории " + s.getInt("lab") + ".");
    }

    public static void finalReport(CompoundTag s, List<String> out) {
        out.add("=== Итоги колонии «Заря» ===");
        out.add("Прошло солов: " + s.getInt("sol") + "/" + SOLS + "; выездов марсохода: " + s.getInt("rover") + ".");
        ListTag tech = s.getList("tech", Tag.TAG_STRING);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < tech.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(tech.getString(i));
        }
        out.add("Исследовательские очки: " + s.getInt("research") + "; аварийных дефицитов: " + s.getInt("shortages") + ".");
        out.add("Открытые технологии: " + (tech.isEmpty() ? "нет" : sb.toString()) + ".");
        out.add("Состояние экипажа:");
        int[] h = s.getIntArray("health");
        for (int i = 0; i < CREW; i++) {
            out.add("- " + CREW_NAMES[i] + " — " + CREW_ROLES[i] + ", здоровье " + h[i] + "%.");
        }
        out.add("Итоговые запасы: вода " + s.getInt("water") + ", еда " + s.getInt("food")
                + ", кислород " + s.getInt("oxygen") + ", энергия " + s.getInt("energy") + ".");
    }
}
