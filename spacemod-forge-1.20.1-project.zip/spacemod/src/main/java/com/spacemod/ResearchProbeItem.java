package com.spacemod;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.registries.ForgeRegistries;

/** Исследовательский зонд: ПКМ — скан планеты/орбиты, ПКМ по инопланетному мобу — наблюдение. */
public class ResearchProbeItem extends Item {
    public ResearchProbeItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide()) {
            return InteractionResultHolder.sidedSuccess(stack, true);
        }
        Planet planet = Planet.fromLevel(level);
        if (planet == null) {
            SpaceData.say(player, "Зонд нужно запускать в космосе, за пределами Земли.");
            return InteractionResultHolder.fail(stack);
        }
        if (planet.kind == Planet.Kind.STATION) {
            SpaceData.say(player, "Станция «Аврора»: здесь нечего сканировать. Здесь можно ремонтировать ракеты.");
            return InteractionResultHolder.fail(stack);
        }
        boolean orbit = planet.kind == Planet.Kind.ORBIT;
        CompoundTag data = SpaceData.root(player);
        String key = (orbit ? "orbit:" : "survey:") + planet.id;
        if (!SpaceData.add(data, "observed", key)) {
            SpaceData.say(player, "Этот объект уже исследован.");
            return InteractionResultHolder.fail(stack);
        }
        int points = orbit ? 10 : 4;
        if (SpaceData.hasTech(player, 2)) {
            points = points * 3 / 2; // анализатор экзоматерии
        }
        if (orbit) {
            SpaceData.say(player, "Выход на орбиту завершён. Посадка невозможна: это газовый или ледяной гигант.");
            SpaceData.say(player, "Зонд сканирует атмосферу и собирает данные дистанционно.");
        } else {
            SpaceData.say(player, "Зонд завершил съёмку поверхности и взял пробы.");
        }
        SpaceData.addResearch(player, points);
        SpaceData.say(player, "Получено " + points + " очков исследований (всего " + SpaceData.research(player) + ").");
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        if (!(target instanceof AlienMob alien)) {
            return InteractionResult.PASS;
        }
        if (player.level().isClientSide()) {
            return InteractionResult.SUCCESS;
        }
        String id = ForgeRegistries.ENTITY_TYPES.getKey((EntityType<?>) target.getType()).getPath();
        AlienMobs.Info info = AlienMobs.get(id);
        if (info == null) {
            return InteractionResult.PASS;
        }
        SpaceData.say(player, "Обнаружен моб: " + target.getName().getString() + " — " + info.desc() + ".");
        SpaceData.say(player, alien.isDangerous()
                ? "Экипаж держится на безопасном расстоянии и наблюдает за существом."
                : "Моб не проявляет агрессии; исследовательский дрон начинает наблюдение.");
        CompoundTag data = SpaceData.root(player);
        if (SpaceData.add(data, "observed", "mob:" + id)) {
            SpaceData.addResearch(player, 3);
            SpaceData.say(player, "Получено 3 очка исследований (всего " + SpaceData.research(player) + ").");
        }
        return InteractionResult.CONSUME;
    }
}
