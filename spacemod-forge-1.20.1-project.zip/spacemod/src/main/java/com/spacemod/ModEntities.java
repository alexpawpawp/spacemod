package com.spacemod;

import java.util.LinkedHashMap;
import java.util.Map;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, SpaceMod.MODID);

    public static final Map<String, RegistryObject<EntityType<AlienCrawler>>> CRAWLERS = new LinkedHashMap<>();
    public static final Map<String, RegistryObject<EntityType<AlienBat>>> BATS = new LinkedHashMap<>();
    public static final Map<String, RegistryObject<EntityType<AlienHunter>>> HUNTERS = new LinkedHashMap<>();

    static {
        for (AlienMobs.Info info : AlienMobs.ALL) {
            final String id = info.id();
            switch (info.kind()) {
                case CRAWLER:
                    CRAWLERS.put(id, ENTITIES.register(id, () -> EntityType.Builder.of(AlienCrawler::new, MobCategory.CREATURE)
                            .sized(0.4F, 0.3F).clientTrackingRange(8).build(SpaceMod.MODID + ":" + id)));
                    break;
                case BAT:
                    BATS.put(id, ENTITIES.register(id, () -> EntityType.Builder.of(AlienBat::new, MobCategory.AMBIENT)
                            .sized(0.5F, 0.9F).clientTrackingRange(5).build(SpaceMod.MODID + ":" + id)));
                    break;
                default:
                    HUNTERS.put(id, ENTITIES.register(id, () -> EntityType.Builder.of(AlienHunter::new, MobCategory.MONSTER)
                            .sized(1.4F, 0.9F).clientTrackingRange(8).build(SpaceMod.MODID + ":" + id)));
            }
        }
    }

    public static EntityType<? extends Mob> typeOf(String id) {
        if (CRAWLERS.containsKey(id)) return CRAWLERS.get(id).get();
        if (BATS.containsKey(id)) return BATS.get(id).get();
        return HUNTERS.get(id).get();
    }
}
