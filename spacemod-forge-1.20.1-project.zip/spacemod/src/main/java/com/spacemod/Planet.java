package com.spacemod;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;

/** Миры мода (сгенерировано). Гравитация — в процентах от земной. */
public enum Planet {
    MOON("moon", 17, Kind.SURFACE),
    MERCURY("mercury", 38, Kind.SURFACE),
    VENUS("venus", 90, Kind.SURFACE),
    MARS("mars", 38, Kind.SURFACE),
    EUROPA("europa", 13, Kind.SURFACE),
    TITAN("titan", 14, Kind.SURFACE),
    PLUTO("pluto", 7, Kind.SURFACE),
    JUPITER("jupiter", 264, Kind.ORBIT),
    SATURN("saturn", 113, Kind.ORBIT),
    URANUS("uranus", 89, Kind.ORBIT),
    NEPTUNE("neptune", 112, Kind.ORBIT),
    AURORA_STATION("aurora_station", 40, Kind.STATION),
    ASTEROID_BELT("asteroid_belt", 5, Kind.SPACE),
    KUIPER_BELT("kuiper_belt", 8, Kind.SPACE),
    ORION_NEBULA("orion_nebula", 5, Kind.ORBIT),
    PROXIMA_B("proxima_b", 110, Kind.SURFACE),
    PROXIMA_D("proxima_d", 70, Kind.SURFACE),
    TRAPPIST_E("trappist_e", 93, Kind.SURFACE),
    TRAPPIST_F("trappist_f", 82, Kind.SURFACE),
    KEPLER_90I("kepler_90i", 145, Kind.SURFACE),
    GLIESE_CC("gliese_cc", 120, Kind.SURFACE),
    GLIESE_CE("gliese_ce", 90, Kind.SURFACE),
    TAU_CETI_E("tau_ceti_e", 110, Kind.SURFACE),
    TAU_CETI_F("tau_ceti_f", 80, Kind.SURFACE),
    GJ273_B("gj273_b", 115, Kind.SURFACE),
    GJ273_C("gj273_c", 72, Kind.SURFACE),
    TOI700_D("toi700_d", 105, Kind.SURFACE),
    TOI700_E("toi700_e", 95, Kind.SURFACE),
    WOLF1061_C("wolf1061_c", 118, Kind.SURFACE),
    WOLF1061_D("wolf1061_d", 130, Kind.SURFACE),
    CANCRI_E("cancri_e", 180, Kind.SURFACE),
    CANCRI_F("cancri_f", 140, Kind.SURFACE),
    KEPLER_90G("kepler_90g", 130, Kind.ORBIT);

    public enum Kind { SURFACE, ORBIT, SPACE, STATION }

    public final String id;
    public final int gravity;
    public final Kind kind;

    Planet(String id, int gravity, Kind kind) {
        this.id = id;
        this.gravity = gravity;
        this.kind = kind;
    }

    public ResourceKey<Level> dimension() {
        return ResourceKey.create(Registries.DIMENSION, new ResourceLocation(SpaceMod.MODID, id));
    }

    public static Planet fromLevel(Level level) {
        for (Planet p : values()) {
            if (level.dimension().equals(p.dimension())) {
                return p;
            }
        }
        return null;
    }
}
