package com.spacemod;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraftforge.items.ItemHandlerHelper;

/** Консоль колонии «Заря»: работает только на Марсе. ПКМ — следующий сол, Shift+ПКМ — новая колония после завершения. */
public class ColonyConsoleBlock extends Block {
    public ColonyConsoleBlock(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide()) {
            return InteractionResult.SUCCESS;
        }
        if (Planet.fromLevel(level) != Planet.MARS) {
            SpaceData.say(player, "Консоль колонии «Заря» работает только на Марсе.");
            return InteractionResult.CONSUME;
        }
        CompoundTag data = SpaceData.root(player);
        List<String> out = new ArrayList<>();

        if (!data.contains("colony", 10)) {
            data.put("colony", ColonySim.fresh());
            out.add("=== Новая кампания: марсианская колония «Заря» ===");
            out.add("Цель: обеспечить экипаж, построить инфраструктуру и открыть научные технологии.");
            out.add("Экипаж: 4 специалиста. Продолжительность: " + ColonySim.SOLS + " солов. ПКМ — следующий сол.");
            out.forEach(line -> SpaceData.say(player, line));
            return InteractionResult.CONSUME;
        }

        CompoundTag colony = data.getCompound("colony");
        if (colony.getBoolean("finished")) {
            if (player.isShiftKeyDown()) {
                data.put("colony", ColonySim.fresh());
                SpaceData.say(player, "Начата новая колония «Заря». ПКМ — следующий сол.");
            } else {
                ColonySim.finalReport(colony, out);
                out.add("Shift+ПКМ — начать новую колонию.");
                out.forEach(line -> SpaceData.say(player, line));
            }
            return InteractionResult.CONSUME;
        }
        if (player.isShiftKeyDown()) {
            SpaceData.say(player, "Колония работает: сол " + colony.getInt("sol") + "/" + ColonySim.SOLS
                    + ". ПКМ без Shift — следующий сол.");
            return InteractionResult.CONSUME;
        }

        boolean finished = ColonySim.advance(colony, out);
        out.forEach(line -> SpaceData.say(player, line));
        if (finished && ColonySim.crewAlive(colony) && !colony.getBoolean("rewarded")) {
            colony.putBoolean("rewarded", true);
            SpaceData.addResearch(player, 20);
            ItemHandlerHelper.giveItemToPlayer(player, new ItemStack(ModItems.TITANIUM_INGOT.get(), 8));
            SpaceData.say(player, "Колония выжила! Награда: 20 очков исследований и 8 титановых слитков.");
        }
        return InteractionResult.CONSUME;
    }
}
