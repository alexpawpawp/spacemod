package com.spacemod;

import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ambient.Bat;
import net.minecraft.world.entity.monster.Silverfish;
import net.minecraft.world.entity.monster.Spider;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SpaceMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModEvents {
    @SubscribeEvent
    public static void onAttributes(EntityAttributeCreationEvent event) {
        ModEntities.CRAWLERS.values().forEach(r -> event.put(r.get(), Silverfish.createAttributes().build()));
        ModEntities.BATS.values().forEach(r -> event.put(r.get(), Bat.createAttributes().build()));
        ModEntities.HUNTERS.values().forEach(r -> event.put(r.get(),
                Spider.createAttributes().add(Attributes.ATTACK_DAMAGE, 4.0D).build()));
    }
}
