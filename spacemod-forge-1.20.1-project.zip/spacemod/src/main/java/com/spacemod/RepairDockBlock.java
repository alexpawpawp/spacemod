package com.spacemod;

import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/** Ремонтный док: чинит ракету за 2 титановых слитка. */
public class RepairDockBlock extends Block {
    public RepairDockBlock(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide()) {
            return InteractionResult.SUCCESS;
        }
        ItemStack held = player.getItemInHand(hand);
        if (!(held.getItem() instanceof RocketItem)) {
            SpaceData.say(player, "Держите ракету в руке: ремонт и дозаправка стоят 2 титановых слитка.");
            return InteractionResult.CONSUME;
        }
        if (!held.isDamaged()) {
            SpaceData.say(player, "Ракета полностью заправлена.");
            return InteractionResult.CONSUME;
        }
        if (!player.isCreative()) {
            int have = 0;
            for (ItemStack s : player.getInventory().items) {
                if (s.is(ModItems.TITANIUM_INGOT.get())) have += s.getCount();
            }
            if (have < 2) {
                SpaceData.say(player, "Не хватает титановых слитков (нужно 2).");
                return InteractionResult.CONSUME;
            }
            int need = 2;
            for (ItemStack s : player.getInventory().items) {
                if (need > 0 && s.is(ModItems.TITANIUM_INGOT.get())) {
                    int take = Math.min(need, s.getCount());
                    s.shrink(take);
                    need -= take;
                }
            }
        }
        held.setDamageValue(0);
        SpaceData.say(player, "Ракета отремонтирована и заправлена.");
        return InteractionResult.CONSUME;
    }
}
