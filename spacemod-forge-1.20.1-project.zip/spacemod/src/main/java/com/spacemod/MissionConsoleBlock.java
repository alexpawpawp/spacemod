package com.spacemod;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraftforge.items.ItemHandlerHelper;

/** Пульт экспедиций: ПКМ — выполнить следующую миссию, Shift+ПКМ — отчёт кампании. */
public class MissionConsoleBlock extends Block {
    public MissionConsoleBlock(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide()) {
            return InteractionResult.SUCCESS;
        }
        CompoundTag data = SpaceData.root(player);
        int done = data.getInt("missions");
        if (player.isShiftKeyDown()) {
            report(player, data, done);
            return InteractionResult.CONSUME;
        }
        if (done >= Missions.ALL.size()) {
            SpaceData.say(player, "Все миссии кампании выполнены!");
            report(player, data, done);
            return InteractionResult.CONSUME;
        }
        Missions.Mission m = Missions.ALL.get(done);
        int research = SpaceData.research(player);
        SpaceData.say(player, "--- Миссия: " + m.name() + " ---");
        if (research < m.required()) {
            SpaceData.say(player, "Миссия пока недоступна: требуется " + m.required()
                    + " очков исследований (у вас " + research + "). Наблюдайте объекты телескопом и сканируйте планеты зондом.");
            return InteractionResult.CONSUME;
        }
        SpaceData.say(player, "Пункт назначения: " + m.destination());
        SpaceData.say(player, "Задача: " + m.objective() + ".");
        if (!SpaceData.has(data, "visited", m.visitId())) {
            SpaceData.say(player, "Вы ещё не были в пункте назначения. Долетите туда на ракете и вернитесь к пульту.");
            return InteractionResult.CONSUME;
        }

        int shipLevel = SpaceData.shipLevel(player);
        int protection = shipLevel + SpaceData.techCount(player);
        SpaceData.say(player, "Уровень корабля: " + shipLevel + ", опасность маршрута: " + m.danger() + "/5.");
        if (protection >= m.danger()) {
            SpaceData.say(player, "Защитные системы справились с опасностями маршрута.");
        } else {
            SpaceData.say(player, "Маршрут опасен: включены резервные щиты и автопилот, но экипаж получил ушибы.");
            float damage = Math.min((m.danger() - protection) * 2.0F, player.getHealth() - 1.0F);
            if (damage > 0) {
                player.hurt(player.damageSources().generic(), damage);
            }
        }
        SpaceData.say(player, "Сканеры выполняют измерения, а дрон берёт образцы. Результаты переданы в лабораторию.");

        data.putInt("missions", done + 1);
        SpaceData.addResearch(player, m.researchReward());
        Item rewardItem = BuiltInRegistries.ITEM.get(new ResourceLocation(m.rewardItem()));
        ItemHandlerHelper.giveItemToPlayer(player, new ItemStack(rewardItem, m.rewardCount()));
        SpaceData.say(player, "Награда: " + m.rewardText() + " (" + m.rewardCount() + " шт.).");
        SpaceData.say(player, "Получено " + m.researchReward() + " очков исследований. Всего: " + SpaceData.research(player) + ".");
        return InteractionResult.CONSUME;
    }

    private static void report(Player player, CompoundTag data, int done) {
        SpaceData.say(player, "=== Итоги кампании ===");
        SpaceData.say(player, "Выполненные миссии: " + done + "/" + Missions.ALL.size());
        for (int i = 0; i < Missions.ALL.size(); i++) {
            Missions.Mission m = Missions.ALL.get(i);
            String status = i < done ? "выполнена" : (SpaceData.research(player) < m.required()
                    ? "заблокирована (нужно " + m.required() + " оч.)" : "доступна");
            SpaceData.say(player, "- " + m.name() + ": " + status);
        }
        StringBuilder techs = new StringBuilder();
        for (int i = 0; i < SpaceData.TECH_AT.length; i++) {
            if (SpaceData.hasTech(player, i)) {
                if (techs.length() > 0) techs.append(", ");
                techs.append(SpaceData.TECH_NAMES[i]);
            }
        }
        SpaceData.say(player, "Технологии корабля: " + (techs.length() == 0 ? "пока не открыты" : techs));
        SpaceData.say(player, "Очки исследований: " + SpaceData.research(player)
                + ", уровень корабля: " + SpaceData.shipLevel(player));
    }
}
