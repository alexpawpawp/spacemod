package com.spacemod;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/** Радиотелескоп: дистанционное наблюдение за чёрными дырами и объектами дальнего космоса. */
public class TelescopeBlock extends Block {
    public TelescopeBlock(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide()) {
            return InteractionResult.SUCCESS;
        }
        CompoundTag data = SpaceData.root(player);
        for (DeepSpaceTarget t : DeepSpaceTarget.ALL) {
            if (!SpaceData.add(data, "observed", t.id())) {
                continue;
            }
            SpaceData.say(player, "=== Дистанционное наблюдение: " + t.type() + " «" + t.name() + "» ===");
            if (t.blackHole()) {
                SpaceData.say(player, "Исследовательский зонд остаётся на безопасном расстоянии от чёрной дыры.");
                SpaceData.say(player, "Гравитационный сканер и телескоп собирают данные без посадки и сближения.");
            } else {
                SpaceData.say(player, "Корабль сохраняет безопасную дистанцию; телескопы и сканеры работают удалённо.");
            }
            SpaceData.say(player, "Объект: " + t.desc());
            SpaceData.say(player, "Научные данные: " + t.reward() + ".");
            int points = t.blackHole() ? 6 : 4;
            SpaceData.addResearch(player, points);
            SpaceData.say(player, "Получено " + points + " очков исследований (всего " + SpaceData.research(player) + ").");
            return InteractionResult.CONSUME;
        }
        SpaceData.say(player, "Все доступные объекты дальнего космоса уже наблюдались.");
        return InteractionResult.CONSUME;
    }
}
