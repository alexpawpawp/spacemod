package com.spacemod;

import java.util.List;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import org.jetbrains.annotations.Nullable;

public class RocketItem extends Item {
    private final Planet planet;

    public RocketItem(Planet planet, Properties properties) {
        super(properties);
        this.planet = planet;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide() || !(player instanceof ServerPlayer sp)) {
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
        }
        MinecraftServer server = sp.server;
        ServerLevel current = sp.serverLevel();
        boolean returning = Planet.fromLevel(current) != null;
        ServerLevel target = returning ? server.overworld() : server.getLevel(planet.dimension());
        if (target == null) {
            sp.displayClientMessage(Component.translatable("message.spacemod.no_dimension"), true);
            return InteractionResultHolder.fail(stack);
        }

        if (!SpaceData.hasTech(sp, 3)) { // «Квантовая связь» убирает перезарядку
            sp.getCooldowns().addCooldown(this, 60);
        }
        SpaceData.say(sp, "Проверка скафандра, кислорода и систем ракеты завершена. Ракета стартует!");
        teleport(sp, target, returning ? null : planet);
        if (returning) {
            sp.displayClientMessage(Component.translatable("message.spacemod.returned"), true);
        } else {
            SpaceData.add(SpaceData.root(sp), "visited", planet.id);
            Component name = Component.translatable("planet.spacemod." + planet.id);
            switch (planet.kind) {
                case ORBIT:
                    sp.displayClientMessage(Component.translatable("message.spacemod.orbit", name, planet.gravity), true);
                    break;
                case SPACE:
                    sp.displayClientMessage(Component.translatable("message.spacemod.space", name, planet.gravity), true);
                    break;
                case STATION:
                    sp.displayClientMessage(Component.translatable("message.spacemod.station", name), true);
                    break;
                default:
                    sp.displayClientMessage(Component.translatable("message.spacemod.arrived", name, planet.gravity), true);
            }
        }
        // «Ионный двигатель» экономит топливо на обратном перелёте
        if (!(returning && SpaceData.hasTech(sp, 1))) {
            stack.hurtAndBreak(1, sp, p -> p.broadcastBreakEvent(hand));
        }
        return InteractionResultHolder.consume(stack);
    }

    private static void teleport(ServerPlayer sp, ServerLevel target, Planet destination) {
        double x = sp.getX();
        double z = sp.getZ();
        if (destination == null) {
            BlockPos spawn = target.getSharedSpawnPos();
            x = spawn.getX() + 0.5;
            z = spawn.getZ() + 0.5;
        }
        int bx = Mth.floor(x);
        int bz = Mth.floor(z);
        target.getChunk(bx >> 4, bz >> 4); // загрузить/сгенерировать чанк
        int y = target.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, bx, bz);
        if (destination != null && destination.kind == Planet.Kind.STATION) {
            buildStation(target, bx, y, bz);
        }
        sp.teleportTo(target, bx + 0.5, y + 1, bz + 0.5, sp.getYRot(), sp.getXRot());
        sp.fallDistance = 0;
    }

    /** На орбитальной станции появляются пульт экспедиций, радиотелескоп и ремонтный док. */
    private static void buildStation(ServerLevel level, int x, int y, int z) {
        place(level, new BlockPos(x + 2, y, z), ModBlocks.MISSION_CONSOLE.get());
        place(level, new BlockPos(x - 2, y, z), ModBlocks.REPAIR_DOCK.get());
        place(level, new BlockPos(x, y, z + 2), ModBlocks.RADIO_TELESCOPE.get());
    }

    private static void place(ServerLevel level, BlockPos pos, net.minecraft.world.level.block.Block block) {
        if (level.getBlockState(pos).isAir()) {
            level.setBlockAndUpdate(pos, block.defaultBlockState());
        }
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.spacemod.rocket",
                Component.translatable("planet.spacemod." + planet.id)));
        tooltip.add(Component.translatable("tooltip.spacemod.rocket_use"));
    }
}
