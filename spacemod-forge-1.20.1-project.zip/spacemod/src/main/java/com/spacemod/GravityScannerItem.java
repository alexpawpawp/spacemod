package com.spacemod;

import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class GravityScannerItem extends Item {
    public GravityScannerItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide()) {
            Planet planet = Planet.fromLevel(level);
            String key = planet == null ? "earth" : planet.id;
            int gravity = planet == null ? 100 : planet.gravity;
            player.displayClientMessage(Component.translatable("message.spacemod.scan",
                    Component.translatable("planet.spacemod." + key), gravity), false);
            player.displayClientMessage(Component.translatable("planet.spacemod." + key + ".desc"), false);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }
}
