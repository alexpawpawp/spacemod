package com.spacemod;

import java.util.function.Supplier;

import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, SpaceMod.MODID);

    public static final RegistryObject<Block> TITANIUM_ORE = ore("titanium_ore");
    public static final RegistryObject<Block> SULFUR_ORE = ore("sulfur_ore");
    public static final RegistryObject<Block> CRYO_CRYSTAL_ORE = ore("cryo_crystal_ore");
    public static final RegistryObject<Block> EXO_CRYSTAL_ORE = ore("exo_crystal_ore");

    public static final RegistryObject<Block> TITANIUM_BLOCK = register("titanium_block",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK).strength(5.0F, 6.0F)));
    public static final RegistryObject<Block> LUNAR_REGOLITH = register("lunar_regolith",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.DIRT).strength(0.8F)));
    public static final RegistryObject<Block> WARP_CORE = register("warp_core",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.OBSIDIAN).lightLevel(s -> 12)));

    public static final RegistryObject<Block> STATION_PLATING = register("station_plating",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK).strength(5.0F, 6.0F)));
    public static final RegistryObject<Block> RADIO_TELESCOPE = register("radio_telescope",
            () -> new TelescopeBlock(BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK).lightLevel(s -> 6)));
    public static final RegistryObject<Block> MISSION_CONSOLE = register("mission_console",
            () -> new MissionConsoleBlock(BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK).lightLevel(s -> 8)));
    public static final RegistryObject<Block> COLONY_CONSOLE = register("colony_console",
            () -> new ColonyConsoleBlock(BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK).lightLevel(s -> 8)));
    public static final RegistryObject<Block> REPAIR_DOCK = register("repair_dock",
            () -> new RepairDockBlock(BlockBehaviour.Properties.copy(Blocks.IRON_BLOCK)));

    private static RegistryObject<Block> ore(String name) {
        return register(name, () -> new DropExperienceBlock(
                BlockBehaviour.Properties.copy(Blocks.IRON_ORE).strength(3.5F, 3.5F),
                UniformInt.of(1, 4)));
    }

    private static RegistryObject<Block> register(String name, Supplier<Block> supplier) {
        RegistryObject<Block> block = BLOCKS.register(name, supplier);
        ModItems.ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties()));
        return block;
    }
}
