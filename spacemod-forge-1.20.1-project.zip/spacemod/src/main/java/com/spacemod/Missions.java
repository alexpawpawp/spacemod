package com.spacemod;

import java.util.List;

/** Экспедиционная кампания: миссии из исходной консольной версии. */
public final class Missions {
    public record Mission(String name, String destination, String visitId, String objective,
                          String rewardText, String rewardItem, int rewardCount,
                          int required, int danger, int researchReward) {}

    public static final List<Mission> ALL = List.of(
            new Mission("Первый сигнал", "Орбитальная станция", "aurora_station", "проверить связь и навигацию",
                    "чертёж улучшенного радара (радиотелескоп)", "spacemod:radio_telescope", 1, 0, 1, 14),
            new Mission("Охотники за астероидами", "Пояс астероидов", "asteroid_belt", "собрать образцы железа и никеля",
                    "железо и никель", "minecraft:iron_ingot", 16, 10, 2, 14),
            new Mission("Ледяной дозор", "Европа", "europa", "просканировать ледяную кору",
                    "образец подлёдного океана", "spacemod:cryo_crystal", 4, 20, 3, 16),
            new Mission("Пески Марса", "Марс", "mars", "найти следы древней воды",
                    "марсианский лёд", "minecraft:packed_ice", 8, 32, 2, 16),
            new Mission("Штормовой рубеж", "орбита Юпитера", "jupiter", "измерить магнитное поле гиганта",
                    "данные о магнитосфере", "minecraft:diamond", 2, 45, 4, 18),
            new Mission("Туманный архив", "Туманность Ориона", "orion_nebula", "изучить облака газа и пыли",
                    "образец космической пыли", "spacemod:exo_crystal", 4, 58, 3, 18),
            new Mission("Море Титана", "Титан", "titan", "снять карту метановых озёр",
                    "метан и этан", "minecraft:blaze_powder", 8, 72, 3, 20),
            new Mission("Граница системы", "Пояс Койпера", "kuiper_belt", "обнаружить новые ледяные тела",
                    "редкий ледяной минерал", "spacemod:cryo_crystal", 8, 86, 5, 22)
    );

    private Missions() {}
}
