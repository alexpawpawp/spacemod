package com.spacemod;

import java.util.List;

/** Инопланетные мобы (сгенерировано). */
public final class AlienMobs {
    public enum Kind { CRAWLER, BAT, HUNTER }

    public record Info(String id, String planet, Kind kind, boolean dangerous, String desc, int rgb) {}

    public static final List<Info> ALL = List.of(
            new Info("ice_microbe", "europa", Kind.CRAWLER, false, "микроорганизм, живущий в подлёдном океане", 0xaadcff),
            new Info("methane_swimmer", "titan", Kind.CRAWLER, false, "небольшое существо, приспособленное к метановым озёрам", 0xe6a03c),
            new Info("proxima_glowworm", "proxima_b", Kind.BAT, false, "светящееся существо, скрывающееся в каменных расщелинах", 0xfff078),
            new Info("crystal_wanderer", "trappist_e", Kind.CRAWLER, false, "мирный организм с панцирем из минералов", 0x5ac8d2),
            new Info("red_digger", "gliese_cc", Kind.CRAWLER, false, "осторожный подземный обитатель", 0xc83c32),
            new Info("dust_hunter", "tau_ceti_e", Kind.HUNTER, true, "быстрый хищник, скрывающийся в облаках пыли", 0xbea05a),
            new Info("reef_builder", "gj273_b", Kind.CRAWLER, false, "мирный колониальный организм, образующий минеральные структуры", 0x3cc8aa),
            new Info("twilight_sailer", "toi700_d", Kind.BAT, false, "летучее существо, использующее плотные воздушные потоки", 0x6e46aa),
            new Info("crystal_creeper", "toi700_e", Kind.CRAWLER, false, "небольшой организм, скрывающийся среди соляных отложений", 0xe6e6eb),
            new Info("wolf_thunderer", "wolf1061_c", Kind.HUNTER, true, "крупное территориальное существо, чувствительное к вибрациям", 0x5a5a6e),
            new Info("lava_shellback", "cancri_e", Kind.HUNTER, true, "термостойкий организм, обитающий вблизи остывающих лавовых потоков", 0xe65a14)
    );

    public static Info get(String id) {
        for (Info i : ALL) {
            if (i.id().equals(id)) return i;
        }
        return null;
    }

    private AlienMobs() {}
}
