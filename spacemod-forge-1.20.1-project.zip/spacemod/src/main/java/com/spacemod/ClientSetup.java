package com.spacemod;

import net.minecraft.client.renderer.entity.BatRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.SilverfishRenderer;
import net.minecraft.client.renderer.entity.SpiderRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ambient.Bat;
import net.minecraft.world.entity.monster.Silverfish;
import net.minecraft.world.entity.monster.Spider;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

@Mod.EventBusSubscriber(modid = SpaceMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {

    static ResourceLocation texture(Entity entity) {
        String path = ForgeRegistries.ENTITY_TYPES.getKey(entity.getType()).getPath();
        return new ResourceLocation(SpaceMod.MODID, "textures/entity/" + path + ".png");
    }

    @SubscribeEvent
    public static void onRenderers(EntityRenderersEvent.RegisterRenderers event) {
        ModEntities.CRAWLERS.values().forEach(r -> event.registerEntityRenderer(r.get(), CrawlerRenderer::new));
        ModEntities.BATS.values().forEach(r -> event.registerEntityRenderer(r.get(), BatAlienRenderer::new));
        ModEntities.HUNTERS.values().forEach(r -> event.registerEntityRenderer(r.get(), HunterRenderer::new));
    }

    public static class CrawlerRenderer extends SilverfishRenderer {
        public CrawlerRenderer(EntityRendererProvider.Context context) {
            super(context);
        }

        @Override
        public ResourceLocation getTextureLocation(Silverfish entity) {
            return texture(entity);
        }
    }

    public static class BatAlienRenderer extends BatRenderer {
        public BatAlienRenderer(EntityRendererProvider.Context context) {
            super(context);
        }

        @Override
        public ResourceLocation getTextureLocation(Bat entity) {
            return texture(entity);
        }
    }

    public static class HunterRenderer extends SpiderRenderer<Spider> {
        public HunterRenderer(EntityRendererProvider.Context context) {
            super(context);
        }

        @Override
        public ResourceLocation getTextureLocation(Spider entity) {
            return texture(entity);
        }
    }
}
