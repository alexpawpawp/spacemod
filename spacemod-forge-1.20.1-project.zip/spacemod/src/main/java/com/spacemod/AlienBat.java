package com.spacemod;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ambient.Bat;
import net.minecraft.world.level.Level;

/** Мирное летающее инопланетное существо (модель летучей мыши, своя текстура). */
public class AlienBat extends Bat implements AlienMob {
    public AlienBat(EntityType<? extends Bat> type, Level level) {
        super(type, level);
    }

    @Override
    public boolean isDangerous() {
        return false;
    }
}
