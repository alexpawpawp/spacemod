package com.spacemod;

import java.util.EnumMap;
import java.util.Map;

import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, SpaceMod.MODID);

    public static final RegistryObject<Item> RAW_TITANIUM = ITEMS.register("raw_titanium",
            () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> TITANIUM_INGOT = ITEMS.register("titanium_ingot",
            () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> SULFUR = ITEMS.register("sulfur",
            () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> CRYO_CRYSTAL = ITEMS.register("cryo_crystal",
            () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> EXO_CRYSTAL = ITEMS.register("exo_crystal",
            () -> new Item(new Item.Properties()));

    public static final RegistryObject<Item> SPACE_HELMET = ITEMS.register("space_helmet",
            () -> new ArmorItem(ModArmorMaterials.SPACE, ArmorItem.Type.HELMET, new Item.Properties()));
    public static final RegistryObject<Item> SPACE_CHESTPLATE = ITEMS.register("space_chestplate",
            () -> new ArmorItem(ModArmorMaterials.SPACE, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
    public static final RegistryObject<Item> SPACE_LEGGINGS = ITEMS.register("space_leggings",
            () -> new ArmorItem(ModArmorMaterials.SPACE, ArmorItem.Type.LEGGINGS, new Item.Properties()));
    public static final RegistryObject<Item> SPACE_BOOTS = ITEMS.register("space_boots",
            () -> new ArmorItem(ModArmorMaterials.SPACE, ArmorItem.Type.BOOTS, new Item.Properties()));

    public static final RegistryObject<Item> GRAVITY_SCANNER = ITEMS.register("gravity_scanner",
            () -> new GravityScannerItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> RESEARCH_PROBE = ITEMS.register("research_probe",
            () -> new ResearchProbeItem(new Item.Properties().stacksTo(1)));

    static {
        for (AlienMobs.Info info : AlienMobs.ALL) {
            final String id = info.id();
            final int base = info.rgb();
            ITEMS.register(id + "_spawn_egg", () -> new ForgeSpawnEggItem(
                    () -> ModEntities.typeOf(id), base, 0x202020, new Item.Properties()));
        }
    }

    /** По одной ракете на каждую планету. Прочность 2: один рейс туда и один обратно. */
    public static final Map<Planet, RegistryObject<Item>> ROCKETS = new EnumMap<>(Planet.class);

    static {
        for (Planet planet : Planet.values()) {
            ROCKETS.put(planet, ITEMS.register("rocket_" + planet.id,
                    () -> new RocketItem(planet, new Item.Properties().durability(2))));
        }
    }
}
