package com.spacemod;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SpaceMod.MODID)
public class SpaceEvents {

    /** Своя гравитация на планетах (работает и на клиенте, и на сервере). */
    @SubscribeEvent
    public static void onLivingTick(LivingEvent.LivingTickEvent event) {
        LivingEntity entity = event.getEntity();
        Planet planet = Planet.fromLevel(entity.level());
        if (planet == null) {
            return;
        }

        boolean flyingPlayer = entity instanceof Player p && p.getAbilities().flying;
        if (!(flyingPlayer || entity.isNoGravity() || entity.onGround() || entity.isInWater()
                || entity.isInLava() || entity.isFallFlying() || entity.onClimbable() || entity.isPassenger())) {
            // В ваниле гравитация тянет вниз на 0.08 за тик — добавляем разницу
            Vec3 motion = entity.getDeltaMovement();
            double extra = 0.08 * (1.0 - planet.gravity / 100.0);
            entity.setDeltaMovement(motion.x, motion.y + extra, motion.z);
        }

        // Без скафандра на планетах и в открытом космосе нет кислорода (на станции воздух есть)
        if (planet.kind != Planet.Kind.STATION
                && entity instanceof ServerPlayer sp && sp.tickCount % 40 == 0
                && !sp.isCreative() && !sp.isSpectator() && !hasFullSuit(sp)) {
            sp.hurt(sp.damageSources().drown(), 2.0F);
            sp.displayClientMessage(Component.translatable("message.spacemod.no_oxygen"), true);
        }
    }

    /** Урон от падения зависит от гравитации. */
    @SubscribeEvent
    public static void onFall(LivingFallEvent event) {
        Planet planet = Planet.fromLevel(event.getEntity().level());
        if (planet != null) {
            event.setDistance(event.getDistance() * planet.gravity / 100.0F);
        }
    }

    /** Прогресс исследований сохраняется после смерти. */
    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        SpaceData.copy(event.getOriginal(), event.getEntity());
    }

    private static boolean hasFullSuit(Player player) {
        for (EquipmentSlot slot : new EquipmentSlot[]{
                EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            ItemStack stack = player.getItemBySlot(slot);
            if (!(stack.getItem() instanceof ArmorItem armor) || armor.getMaterial() != ModArmorMaterials.SPACE) {
                return false;
            }
        }
        return true;
    }
}
