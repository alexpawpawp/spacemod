package com.spacemod;

public interface AlienMob {
    boolean isDangerous();
}
